import MBTIGame from "../components/MBTIGame";

export default function Home() {
  return <MBTIGame />;
}
